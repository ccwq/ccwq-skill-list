#!/usr/bin/env node
/**
 * Execute a git-up YAML-lite commit plan.
 *
 * The parser intentionally supports only the small YAML subset emitted by
 * git-up -p. It is not a general YAML parser.
 *
 * Two execution modes are supported:
 *
 * - File mode: a plan that declares `files`. Each step stages exactly the
 *   listed paths with `git add -- <files...>`.
 * - Semantic mode: a plan that declares `changes`. Each step applies its own
 *   patch to the index, so one file can be split across several commits.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';

import {
  CODE_INVALID_PLAN,
  CODE_VERIFICATION,
  PlanError,
  captureTargetSnapshot,
  clearIndex,
  collectScope,
  ensureCleanIndex,
  executeSemanticPlan,
  literalPathspec,
  parsePlan,
  planMode,
  runGit,
  semanticSplitReasons,
  stagedPaths,
  stepMessage,
  stepToDict,
  topologicalOrder,
  validateSemanticPlan,
  verifyTarget,
} from './gitup_semantic.mjs';

/** 读取 stdin 的全部内容。 */
async function readStdin() {
  if (process.stdin.isTTY) return '';
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

function failGit(step, completed, command, result) {
  return {
    ok: false,
    code: 'git_failed',
    step,
    completed_steps: completed,
    command,
    returncode: result.status,
    stdout: result.stdout,
    stderr: result.stderr,
  };
}

/** 汇总各步骤声明的抑制拆分路径，去重后排序。 */
function collectSuppressedSplit(steps) {
  const paths = steps.flatMap((item) => item.suppressedSplit ?? []);
  return [...new Set(paths)].sort();
}

/** 生成 ez-fast 拒绝语义计划的错误消息，指出第一个声明 changes 的步骤。 */
function ezFastSemanticPlanMessage(steps) {
  const offending = steps.find((item) => item.changes.length > 0);
  const stepNo = offending ? offending.step : '?';
  return `the --ez-fast flag forbids semantic plans; step ${stepNo} declares changes`;
}

/**
 * ez-fast 拒绝语义计划的错误结果。
 *
 * parse 与 commit 两个子命令共用同一份消息，拒绝语义一致。
 */
function ezFastRejectsSemanticPlan(steps) {
  return {
    ok: false,
    code: CODE_INVALID_PLAN,
    message: ezFastSemanticPlanMessage(steps),
  };
}

/**
 * ez-fast 的结果字段。
 *
 * 非 ez-fast 场景返回空对象，两个键都不出现，现有结果契约保持字节级不变。
 */
function ezFastResultFields(steps, ezFast) {
  if (!ezFast) return {};
  return {
    semantic_split_disabled: true,
    suppressed_split: collectSuppressedSplit(steps),
  };
}

/** 执行兼容的文件级计划。每个步骤只暂存计划显式列出的路径。 */
export function executeFilePlan(steps, cwd, fastPathUsed = false, ezFast = false) {
  const preflight = ensureCleanIndex(cwd);
  if (preflight !== null) return preflight;

  let ordered;
  let scope;
  let snapshot;
  try {
    // depends_on 是计划模型的共享字段。文件级模式同样按依赖排序并校验。
    ordered = topologicalOrder(steps);
    scope = [...new Set(steps.flatMap((item) => item.files))].sort();
    snapshot = captureTargetSnapshot(cwd, scope);
  } catch (error) {
    if (error instanceof PlanError) return error.toDict();
    throw error;
  }

  const completed = [];
  const skipped = [];
  const commits = [];

  for (const item of ordered) {
    // 每步先清空并复查暂存区，避免上一步的残留混入本次提交。
    const [cleared, clearMessage] = clearIndex(cwd);
    if (!cleared) {
      return {
        ok: false,
        code: 'git_failed',
        step: item.step,
        message: `failed to clear the index before step ${item.step}: ${clearMessage.trim()}`,
        completed_steps: completed,
      };
    }

    const addResult = runGit(['add', '--', ...item.files.map(literalPathspec)], cwd);
    if (addResult.status !== 0) {
      clearIndex(cwd);
      return failGit(item.step, completed, ['git', 'add', '--', ...item.files], addResult);
    }

    // 一次 `git diff --cached --name-only --no-renames -z` 同时回答两件事：
    // 暂存区是否有差异（路径列表非空），以及差异涉及哪些路径。
    // 此前先 `git diff --cached --quiet` 判差异，再取一次路径列表，
    // 同一状态探测了两遍，每次多付一次进程创建开销。
    //
    // 读取失败仍按失败处理，不能当成「无差异」把整步静默跳过。
    const stagedResult = stagedPaths(cwd);
    if (stagedResult.error) {
      clearIndex(cwd);
      return {
        ok: false,
        code: 'git_failed',
        step: item.step,
        message: `failed to inspect the staged paths: ${stagedResult.error}`,
        completed_steps: completed,
      };
    }

    const paths = stagedResult.paths;

    if (paths.length === 0) {
      skipped.push(item.step);
      continue;
    }

    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'git-up-msg-'));
    const messagePath = path.join(tmpDir, 'message.txt');
    let commitResult;
    try {
      fs.writeFileSync(messagePath, stepMessage(item), 'utf8');
      commitResult = runGit(['commit', '-F', messagePath], cwd);
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }

    if (commitResult.status !== 0) {
      clearIndex(cwd);
      return failGit(item.step, completed, ['git', 'commit', '-F', '<tempfile>'], commitResult);
    }
    completed.push(item.step);
    commits.push({
      step: item.step,
      sha: runGit(['rev-parse', 'HEAD'], cwd).stdout.trim(),
      subject: item.subject,
      reason: item.reason,
      paths,
      status: 'committed',
    });
  }

  const verification = verifyTarget(cwd, snapshot);
  if (!verification.ok) {
    return {
      ok: false,
      code: CODE_VERIFICATION,
      message: `target verification failed: ${verification.reason}`,
      step: null,
      ...ezFastResultFields(steps, ezFast),
      verification,
      completed_steps: completed,
      skipped_steps: skipped,
    };
  }

  const logCount = Math.max(completed.length, 1);
  const logResult = runGit(['log', '--oneline', `-${logCount}`], cwd);
  if (logResult.status !== 0) {
    return failGit(null, completed, ['git', 'log', '--oneline', `-${logCount}`], logResult);
  }

  return {
    ok: true,
    mode: 'file',
    fast_path_used: fastPathUsed,
    ...ezFastResultFields(steps, ezFast),
    base_head: snapshot.base_head,
    final_head: runGit(['rev-parse', 'HEAD'], cwd).stdout.trim(),
    target_tree: snapshot.target_tree,
    final_tree: verification.final_tree,
    completed_steps: completed,
    skipped_steps: skipped,
    commits,
    verification,
    git_log: logResult.stdout.trim(),
  };
}

/** 按计划模式选择执行器。语义模式不会回退到文件级暂存。 */
export function executePlan(steps, cwd, fastPathUsed = false, ezFast = false) {
  if (planMode(steps) === 'semantic') {
    // ez-fast 禁止语义计划。拒绝发生在任何 Git 写操作之前，index 不被触碰。
    if (ezFast) {
      return ezFastRejectsSemanticPlan(steps);
    }
    if (fastPathUsed) {
      return {
        ok: false,
        code: CODE_INVALID_PLAN,
        message: 'the fast path cannot execute a semantic plan; run the full planning flow instead',
      };
    }
    return executeSemanticPlan(steps, cwd);
  }
  return executeFilePlan(steps, cwd, fastPathUsed, ezFast);
}

function printJson(payload) {
  process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
}

function parseArgs(argv) {
  const options = { mode: null, cwd: '.', planFile: null, fastPath: false, ezFast: false };
  const takeValue = (name, index) => {
    const value = argv[index];
    if (value === undefined) {
      throw new Error(`${name} requires a value`);
    }
    return value;
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === 'parse' || arg === 'commit') {
      options.mode = arg;
    } else if (arg === '--cwd') {
      options.cwd = takeValue('--cwd', i + 1);
      i += 1;
    } else if (arg === '--plan-file') {
      options.planFile = takeValue('--plan-file', i + 1);
      i += 1;
    } else if (arg === '--fast-path') {
      options.fastPath = true;
    } else if (arg === '--ez-fast') {
      options.ezFast = true;
    } else if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  return options;
}

const USAGE = `usage: commit_plan.mjs {parse|commit} [--cwd DIR] [--plan-file FILE] [--fast-path] [--ez-fast]

Parse or execute a git-up YAML-lite commit plan.

  parse            解析计划并输出结构化结果，不做任何 Git 写操作
  commit           按计划执行提交
  --cwd DIR        Git 仓库工作目录，默认当前目录
  --plan-file FILE 从 UTF-8 文件读取计划（Windows PowerShell 推荐）
  --fast-path      标记本次执行是已校验的 -pc/-pcP 快车道
  --ez-fast        标记本次执行处于 ez-fast 上下文：禁止语义计划，并放宽规划质量级检查
`;

async function main(argv) {
  let options;
  try {
    options = parseArgs(argv);
  } catch (error) {
    process.stderr.write(`${error.message}\n${USAGE}`);
    return 2;
  }

  if (options.help) {
    process.stdout.write(USAGE);
    return 0;
  }
  if (!options.mode) {
    process.stderr.write(USAGE);
    return 2;
  }

  const cwd = path.resolve(options.cwd);
  let text;
  try {
    // 读取 UTF-8 文件可避开 PowerShell 5.1 原生管道把中文和 emoji 替换成 ? 的问题。
    text = options.planFile
      ? fs.readFileSync(options.planFile, 'utf8').replace(/^﻿/, '')
      : await readStdin();
  } catch (error) {
    printJson({ ok: false, code: 'plan_file_read_failed', message: String(error.message ?? error) });
    return 2;
  }

  let steps;
  try {
    steps = parsePlan(text);
  } catch (error) {
    if (error instanceof PlanError) {
      printJson(error.toDict());
      return 2;
    }
    throw error;
  }

  const mode = planMode(steps);

  if (options.mode === 'parse') {
    // ez-fast 上下文里语义计划本身就是无效计划，parse 与 commit 用同一条消息拒绝。
    if (options.ezFast && mode === 'semantic') {
      printJson(ezFastRejectsSemanticPlan(steps));
      return 2;
    }
    const payload = { ok: true, plan_mode: mode, steps: steps.map((item) => stepToDict(item)) };
    try {
      if (mode === 'semantic') {
        validateSemanticPlan(steps, cwd);
        payload.semantic_split_reasons = semanticSplitReasons(steps, cwd);
        payload.scope_paths = collectScope(steps);
      }
    } catch (error) {
      if (error instanceof PlanError) {
        printJson(error.toDict());
        return 2;
      }
      throw error;
    }
    printJson(payload);
    return 0;
  }

  const result = executePlan(steps, cwd, options.fastPath, options.ezFast);
  printJson(result);
  return result.ok ? 0 : 1;
}

main(process.argv.slice(2))
  .then((code) => {
    process.exitCode = code;
  })
  .catch((error) => {
    process.stderr.write(`${error?.stack ?? error}\n`);
    process.exitCode = 1;
  });
